// api/recover.js — Vercel Edge Function
// Proxies requests to Anthropic API so your key is never exposed to the browser

export const config = { runtime: 'edge' };

export default async function handler(req) {
  // Only allow POST
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // CORS — replace with your actual domain in production
  const origin = req.headers.get('origin') || '';
  const allowedOrigins = [
    process.env.ALLOWED_ORIGIN || '',   // e.g. https://yourdomain.com
    'http://localhost:3000',             // for local dev
  ];

  if (!allowedOrigins.includes(origin)) {
    return new Response(JSON.stringify({ error: 'Forbidden' }), {
      status: 403,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  try {
    const body = await req.json();
    const { notes, meetname, yourname } = body;

    if (!notes || notes.trim().length < 10) {
      return new Response(JSON.stringify({ error: 'Notes are too short.' }), {
        status: 400,
        headers: corsHeaders(origin),
      });
    }

    const prompt = `You are a meeting recovery assistant. Given raw, messy meeting notes, extract and return a JSON object with exactly these keys:

{
  "summary": "2-3 sentence plain-English summary of what was discussed and decided",
  "actions": [
    { "who": "Name or 'Team'", "task": "specific action item" }
  ],
  "email": "A short professional follow-up email. Subject line first (prefix with 'Subject: '), then a blank line, then the body. Sign off with '${yourname || 'the team'}'. Reference the meeting as '${meetname || 'our meeting'}'. Do not use markdown."
}

Return ONLY valid JSON, no markdown fences, no preamble.

Meeting notes:
${notes}`;

    const anthropicRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,   // stored in Vercel env vars
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!anthropicRes.ok) {
      const err = await anthropicRes.json();
      throw new Error(err.error?.message || 'Anthropic API error');
    }

    const data = await anthropicRes.json();
    const raw = data.content.map(b => b.text || '').join('');
    const clean = raw.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    return new Response(JSON.stringify(parsed), {
      status: 200,
      headers: { 'Content-Type': 'application/json', ...corsHeaders(origin) },
    });

  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders(origin) },
    });
  }
}

function corsHeaders(origin) {
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };
}
