# Meeting Recovery

Turn messy meeting notes into a clean summary, action items, and a follow-up email — powered by Claude AI.

---

## Deploy in 5 minutes (no coding needed)

### Step 1 — Get your Anthropic API key
1. Go to https://console.anthropic.com
2. Sign up / log in
3. Click **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-...`)

### Step 2 — Put this code on GitHub
1. Go to https://github.com and create a free account if you don't have one
2. Click **+** → **New repository** → name it `meeting-recovery` → **Create**
3. Upload all files from this folder (drag & drop in the GitHub UI)

### Step 3 — Deploy to Vercel (free)
1. Go to https://vercel.com and sign up with your GitHub account
2. Click **Add New → Project**
3. Select your `meeting-recovery` repo → click **Import**
4. Before clicking Deploy, click **Environment Variables** and add:
   - `ANTHROPIC_API_KEY` → paste your key from Step 1
   - `ALLOWED_ORIGIN` → leave blank for now (add your domain later)
5. Click **Deploy**

Vercel gives you a free URL like `https://meeting-recovery-xyz.vercel.app` — that's your live app!

### Step 4 — Add your domain (optional)
1. In Vercel, go to your project → **Settings** → **Domains**
2. Add your domain (e.g. `meetingrecovery.com`)
3. Update the `ALLOWED_ORIGIN` environment variable to match (e.g. `https://meetingrecovery.com`)

---

## Project structure

```
meeting-recovery/
├── api/
│   └── recover.js      ← Vercel Edge Function (your API key lives here, safe)
├── public/
│   └── index.html      ← The full frontend app
├── vercel.json         ← Routing config
└── README.md
```

## How it works

- The frontend (`index.html`) sends your notes to `/api/recover`
- The Edge Function (`api/recover.js`) adds your secret API key and calls Anthropic
- Your API key is **never** exposed to the browser — it only lives in Vercel's environment
- Vercel auto-deploys whenever you push changes to GitHub — zero maintenance

## Environment variables

| Variable | Description | Required |
|---|---|---|
| `ANTHROPIC_API_KEY` | Your Anthropic API key | Yes |
| `ALLOWED_ORIGIN` | Your production domain (e.g. `https://yourdomain.com`) | Recommended |

## Costs

- Vercel hosting: **free**
- Anthropic API: roughly **$0.003 per recovery** (Claude Sonnet)
- At 1,000 recoveries/month → ~$3/month in API costs

## Future upgrades (when you're ready)

- Add Clerk (https://clerk.com) for user accounts and usage limits
- Add Supabase (https://supabase.com) to save recovery history
- Add Lemon Squeezy (https://lemonsqueezy.com) for paid subscriptions
